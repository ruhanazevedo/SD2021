/********* Grupo 9 ********
* 44898 - José Alves      *
* 46670 - Tiago Lourenço  *
* 51779 - Ruhan Azevedo   *
***************************/

#ifndef _DATA_PRIVATE_H
#define _DATA_PRIVATE_H

//#include "data.h"

/*
* Função que imprime o conteúdo do data_t recebido
*/
void data_print(struct data_t *data);

#endif
