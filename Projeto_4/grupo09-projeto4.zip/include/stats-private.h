/********* Grupo 9 ********
* 44898 - José Alves      *
* 46670 - Tiago Lourenço  *
* 51779 - Ruhan Azevedo   *
***************************/


#ifndef _STATS_PRIVATE_H
#define _STATS_PRIVATE_H


struct statistics{
    int n_put;
    int n_get;
    int n_del;
    int n_size;
    int n_getkeys;
    int n_table_print;
    float avg_time;
    };

#endif